// Data for menu items
const menuItems = [
    { name: "Breakfast Croissant", price: 100, img: "item1.jpg" },
    { name: "Cheese Bagel", price: 120, img: "item2.jpg" },
    { name: "Grilled Chicken Sandwich", price: 150, img: "item3.jpg" },
    { name: "Grilled Cheese", price: 200, img: "item4.jpg" },
    { name: "Choco Shake", price: 180, img: "item5.jpg" },
];

// Function to populate menu dynamically
function populateMenu() {
    const menuContainer = document.getElementById('menu-container');
    if (menuContainer) {
        menuContainer.innerHTML = ""; // Clear existing items
        menuItems.forEach(item => {
            const menuItem = document.createElement('div');
            menuItem.classList.add('menu-item');

            menuItem.innerHTML = `
                <img src="${item.img}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>Price: PKR ${item.price}</p>
                <div class="quantity">
                    <label for="quantity">Qty:</label>
                    <input type="number" value="1" min="1">
                </div>
                <button class="add-to-cart">Add to Cart</button>
            `;

            menuContainer.appendChild(menuItem);
        });
    }
}

// Automatically populate the menu if on the menu page
document.addEventListener("DOMContentLoaded", () => {
    const currentPage = window.location.pathname.split('/').pop();
    if (currentPage === 'menu.html') {
        populateMenu();
    }
});
